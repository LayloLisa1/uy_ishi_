const express = require('express');
const router = express.Router();
const authorController = require('../controllers/authorController');
const categoryController = require('../controllers/categoryController');

router.post('/authors', authorController.createAuthor);
router.get('/authors', authorController.getAuthors);
router.get('/authors/:id', authorController.getAuthorById);
router.put('/authors/:id', authorController.updateAuthor);
router.delete('/authors/:id', authorController.deleteAuthor);

router.post('/categories', categoryController.createCategory);
router.get('/categories', categoryController.getCategories);
router.get('/categories/:id', categoryController.getCategoryById);
router.put('/categories/:id', categoryController.updateCategory);
router.delete('/categories/:id', categoryController.deleteCategory);

module.exports = router;
