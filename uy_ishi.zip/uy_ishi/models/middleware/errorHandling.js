const { ValidationError, AuthenticationError, NotFoundError } = require('./utils/errors');

const errorHandler = (err, req, res, next) => {
  if (err instanceof ValidationError || err instanceof AuthenticationError || err instanceof NotFoundError) {
    return res.status(err.statusCode).json({ error: err.message });
  }

  console.error(err);
  res.status(500).json({ error: 'Internal Server Error' });
};

module.exports = errorHandler;
