const jwt = require('jsonwebtoken');
const { AuthenticationError } = require('../utils/errors');

const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];
  if (!token) return next(new AuthenticationError('Access token required'));

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return next(new AuthenticationError('Invalid token'));
    req.user = user;
    next();
  });
};

module.exports = authenticateJWT;
