const User = require('../models/user');
const otpGenerator = require('otp-generator');
const { sendOtpEmail } = require('../utils/emailService');
const { AuthenticationError, ValidationError } = require('../utils/errors');

const generateOtp = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) throw new ValidationError('Email not registered');

    const otp = otpGenerator.generate(6, { upperCase: false, specialChars: false });
    user.otp = otp;
    await user.save();
    await sendOtpEmail(user.email, otp);
    res.json({ message: 'OTP sent to your email' });
  } catch (error) {
    next(error);
  }
};

const verifyOtp = async (req, res, next) => {
  try {
    const { email, otp } = req.body;
    const user = await User.findOne({ email });
    if (!user || user.otp !== otp) throw new AuthenticationError('Invalid OTP');

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    user.otp = null; // Clear OTP after successful verification
    await user.save();
    res.json({ token });
  } catch (error) {
    next(error);
  }
};

module.exports = { generateOtp, verifyOtp };
