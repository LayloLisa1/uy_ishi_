const { Author } = require('../models');
const { NotFoundError } = require('../utils/errors');

const createAuthor = async (req, res, next) => {
  try {
    const author = new Author(req.body);
    await author.save();
    res.status(201).json(author);
  } catch (error) {
    next(error);
  }
};

const getAuthors = async (req, res, next) => {
  try {
    const authors = await Author.find();
    res.json(authors);
  } catch (error) {
    next(error);
  }
};

const getAuthorById = async (req, res, next) => {
  try {
    const author = await Author.findById(req.params.id);
    if (!author) throw new NotFoundError('Author not found');
    res.json(author);
  } catch (error) {
    next(error);
  }
};

const updateAuthor = async (req, res, next) => {
  try {
    const author = await Author.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!author) throw new NotFoundError('Author not found');
    res.json(author);
  } catch (error) {
    next(error);
  }
};

const deleteAuthor = async (req, res, next) => {
  try {
    const author = await Author.findByIdAndDelete(req.params.id);
    if (!author) throw new NotFoundError('Author not found');
    res.json({ message: 'Author deleted successfully' });
  } catch (error) {
    next(error);
  }
};

module.exports = { createAuthor, getAuthors, getAuthorById, updateAuthor, deleteAuthor };
