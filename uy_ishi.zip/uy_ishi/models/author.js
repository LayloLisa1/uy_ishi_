const mongoose = require('mongoose');

const AuthorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  bio: String,
});

const CategorySchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
});

const Author = mongoose.model('Author', AuthorSchema);
const Category = mongoose.model('Category', CategorySchema);

module.exports = { Author, Category };
